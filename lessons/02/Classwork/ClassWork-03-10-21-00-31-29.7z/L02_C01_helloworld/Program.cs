using System;

namespace L02_C01_helloworld
{
	class Program
	{
		// start of external block
		static void Main()
		{
			Console.WriteLine("Enter two numbers: ");
			double left = double.Parse(Console.ReadLine());
			double right = double.Parse(Console.ReadLine());
			Console.WriteLine(left + right);

			Boolean condition = false;
			if (!condition)
			{
			}

			int flag = 1;
			if (flag !>1)
			{
			}
		}
		
	}
} // end of external block