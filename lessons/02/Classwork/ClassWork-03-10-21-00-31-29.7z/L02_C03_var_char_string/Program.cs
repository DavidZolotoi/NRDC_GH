using System;

namespace L02_C03_var_char_string
{
	class Program
	{
		static void Main()
		{
			char letter = 'A'; // declaring a single-char variable
			Console.WriteLine(letter);

			string name = "Bob"; // declaring a string variable
			Console.WriteLine(name);
		}
	}
}
